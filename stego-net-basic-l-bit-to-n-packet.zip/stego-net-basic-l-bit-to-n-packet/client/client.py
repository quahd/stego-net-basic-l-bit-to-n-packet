import time
from scapy.all import IP, ICMP, send
import argparse

parser = argparse.ArgumentParser(description="Gửi thông điệp bí mật bằng phương pháp 2-bit to 1-packet qua ICMP.")
parser.add_argument('message', type=str, help="Thông điệp bí mật cần gửi.")
parser.add_argument('destination_ip', type=str, help="Địa chỉ IP đích.")
args = parser.parse_args()

def encode_bit_pair(bit_pair):
    """Mã hóa cặp bit thành thời gian chờ giữa các gói tin (giây)."""
    if bit_pair == "10":
        return 0.06  # 60 ms
    elif bit_pair == "01":
        return 0.08  # 80 ms
    elif bit_pair == "11":
        return 0.10  # 100 ms
    elif bit_pair == "00":
        return 0.12  # 120 ms
    else:
        raise ValueError(f"Chuỗi bit không hợp lệ: {bit_pair}")

def string_to_bit_pairs(input_string):
    """Chuyển đổi chuỗi thành các cặp bit."""
    binary_string = ''.join(format(ord(char), '08b') for char in input_string)
    bit_pairs = [binary_string[i:i+2] for i in range(0, len(binary_string), 2)]
    return bit_pairs

def send_secret_message_ipt(destination_ip, message):
    """Gửi thông điệp bí mật bằng phương pháp Inter-Packet Timing (2-bit to 1-packet)."""
    bit_pairs = string_to_bit_pairs(message)
    print(f"Đang gửi thông điệp '{message}' đến {destination_ip} dưới dạng các cặp bit: {bit_pairs}")

    for pair in bit_pairs:
        try:
            delay = encode_bit_pair(pair)
            ip_layer = IP(dst=destination_ip)
            icmp_layer = ICMP()
            packet = ip_layer / icmp_layer
            send(packet, verbose=0)
            time.sleep(delay)
        except ValueError as e:
            print(f"Lỗi mã hóa: {e}")

    # Gửi một gói tin cuối cùng để đánh dấu kết thúc (có thể tùy chỉnh)
    ip_layer = IP(dst=destination_ip)
    icmp_layer = ICMP()
    send(packet, verbose=0)
    
    time.sleep(5)  # Đợi 5 giây trước khi kết thúc
    send(packet, verbose=0)  # Gửi gói tin cuối cùng
    print("Hoàn tất gửi thông điệp.")

if __name__ == "__main__":
    secret_message = args.message
    target_ip = args.destination_ip
    send_secret_message_ipt(target_ip, secret_message)


