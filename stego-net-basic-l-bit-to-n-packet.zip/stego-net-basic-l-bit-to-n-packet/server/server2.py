from scapy.all import sniff, ICMP, IP

timestamps = []
string_bin = ""  # Biến toàn cục để lưu chuỗi nhị phân

def icmp_handler(packet):
    global string_bin  # Khai báo string_bin là biến toàn cục
    if packet.haslayer(ICMP) and packet[ICMP].type == 0:  # ICMP Echo Reply
        print("Nhận được 1 gói tin từ", packet[IP].src)
        timestamps.append(packet.time)
        if len(timestamps) > 1:
            temp = timestamps[-1] - timestamps[-2]
            print(f"Khoảng thời gian giữa hai gói ICMP: {temp:.6f} giây")
            if temp < 0.08:
                string_bin += "0000"
            elif temp < 0.1:
                string_bin += "0001"
            elif temp < 0.12:
                string_bin += "0010"
            elif temp < 0.14:
                string_bin += "0011"
            elif temp < 0.16:
                string_bin += "0100"
            elif temp < 0.18:
                string_bin += "0101"
            elif temp < 0.2:
                string_bin += "0110"
            elif temp < 0.22:
                string_bin += "0111"
            elif temp < 0.24:
                string_bin += "1000"
            elif temp < 0.26:
                string_bin += "1001"
            elif temp < 0.28:
                string_bin += "1010"
            elif temp < 0.3:
                string_bin += "1011"
            elif temp < 0.32:
                string_bin += "1100"
            elif temp < 0.34:
                string_bin += "1101"
            elif temp < 0.36:
                string_bin += "1110"
            elif temp < 0.38:
                string_bin += "1111"
            
            if temp > 5:
                print("Đã hoàn tất gói tin")
                print(string_bin)  # In chuỗi nhị phân

print("Đang lắng nghe các gói ICMP đến...")
sniff(filter="icmp", prn=icmp_handler, store=0)  # Chạy vô hạn
